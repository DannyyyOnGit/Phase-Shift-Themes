Feature Details
================
This feature brings back section alerts and the 3D section indicator.

Installation
================
1. Put the "dynamic" folder inside the Rock Band 2 dynamic folder (replace all)
2. Put the "static" folder inside the Rock Band 2 static folder (replace all)
3. Restart Phase Shift to reload and play