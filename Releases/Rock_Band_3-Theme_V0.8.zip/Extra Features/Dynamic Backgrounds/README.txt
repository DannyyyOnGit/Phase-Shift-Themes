Feature Details
================
Custom dynamic backgrounds for Phase Shift.

Warning
================
These backgrounds may potentially trigger seizures for people with photosensitive epilepsy.

Installation
================
1. Put any selected folder inside the "abstract" backgrounds folder (...Steam\SteamApps\common\Phase Shift\data\backgrounds\abstract)
2. Restart Phase Shift if it's already running
3. Go to the options menu and toggle background to "3D abstract"
3. Select your active abstract background below