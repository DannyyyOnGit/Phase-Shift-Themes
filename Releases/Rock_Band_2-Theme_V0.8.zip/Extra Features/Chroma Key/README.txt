Feature Details
================
Custom chroma key friendly backgrounds for YouTubers and Streamers.

Installation
================
1. Put the "2d" folder inside the 2d backgrounds folder (...Steam\SteamApps\common\Phase Shift\data\backgrounds\2d)
2. Restart Phase Shift if it's already running
3. Go to the options menu and select your 2d background