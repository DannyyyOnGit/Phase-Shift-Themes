Theme Details
================
Rock Band 2 Theme for Phase Shift (Steam Edition)
Created by: JD2504
Ported by: TheRealDannyyy
Contributions by: Bluzer, Tarmac and oddbrother

Installation
================
1. Put the "Rock Band 2" folder inside Phase Shift "themes" folder (...Steam\SteamApps\common\Phase Shift\themes)
2. Select "Rock Band 2" inside options menu
3. Enable "Menu video background" inside options menu
4. Set "Neck" in profile options to "default"
5. Restart Phase Shift to reload and play

Change Log
================
V0.1
- Initial setup
- Minor hotfixes