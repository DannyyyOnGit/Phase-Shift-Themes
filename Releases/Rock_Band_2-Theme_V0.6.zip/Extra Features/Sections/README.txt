Feature Details
================
This feature brings back section alerts and the 3D section Indicator.

Installation
================
1. Put the "dynamic" folder inside the Rockband 2 dynamic folder (replace all)
2. Put the "static" folder inside the Rockband 2 static folder (replace all)
3. Restart Phase Shift to reload and play