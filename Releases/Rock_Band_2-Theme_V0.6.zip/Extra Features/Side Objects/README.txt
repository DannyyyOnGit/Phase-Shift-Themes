Feature Details
================
This feature brings back the 3D side objects.

Installation
================
1. Put the "static" folder inside the Rockband 2 static folder (replace all)
2. Restart Phase Shift to reload and play